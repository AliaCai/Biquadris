#ifndef TBLOCK_H
#define TBLOCK_H
#include <iostream>
#include <vector>
#include "block.h"
using namespace std;

class TBlock: public Block{
    public:
    TBlock(int level); 
};

#endif
