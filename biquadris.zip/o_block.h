#ifndef OBLOCK_H
#define OBLOCK_H
#include <iostream>
#include <vector>
#include "block.h"
using namespace std;

class OBlock: public Block{
    public:
    OBlock(int level);
};

#endif
