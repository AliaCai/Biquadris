#ifndef JBLOCK_H
#define JBLOCK_H
#include <iostream>
#include <vector>
#include "block.h"
using namespace std;

class JBlock: public Block{
    public:
    JBlock(int level); 
};

#endif
