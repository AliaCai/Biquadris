#ifndef SPECIAL_ACTIONS_H
#define SPECIAL_ACTIONS_H
#include <iostream>

class SpecialActions {
    int action; //not required
    public:
    void blind();
    void force();
    void heavy();

};

#endif




