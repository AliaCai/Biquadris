#include "t_block.h"
#include <vector>
using namespace std;

TBlock::TBlock(int level) : Block{'T', {{0,2}, {1,2}, {2,2}, {1,3}}, 
                    {{{1,-1}, {0,0}, {-1,1}, {-1,-1}},
                    {{1,2}, {0,1}, {-1,0}, {1,0}}, 
                    {{-2,0}, {-1,-1}, {0,-2}, {0,0}},
                    {{0,-1}, {1,0}, {2,1}, {0,1}}}, level} {}

