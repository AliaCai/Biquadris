#ifndef LBLOCK_H
#define LBLOCK_H
#include <iostream>
#include <vector>
#include "block.h"
using namespace std;

class LBlock: public Block{

    public:
    LBlock(int level); 
};

#endif
