#ifndef ZBLOCK_H
#define ZBLOCK_H
#include <iostream>
#include <vector>
#include "block.h"
using namespace std;

class ZBlock: public Block{
    public:
    ZBlock(int level); 

};

#endif
